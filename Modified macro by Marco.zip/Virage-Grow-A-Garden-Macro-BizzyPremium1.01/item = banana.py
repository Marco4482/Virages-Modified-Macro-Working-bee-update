item = banana
item = apple 
item_name = tangereen

print(item,item)

print('hello' + item_name)